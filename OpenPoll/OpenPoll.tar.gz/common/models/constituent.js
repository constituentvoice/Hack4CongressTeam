module.exports = function(Constituent) {

};
